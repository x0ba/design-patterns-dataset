// probe.gl, MIT license
// This file "quarantines" the dynamic import of asciify-image
// in a separate source file that can be excluded in browser builds via package.json
// browser statement. https://github.com/uber-web/probe.gl/issues/196

/** Use the asciify-image module, if installed, to log an image under node.js */
export function nodeAsciifyImage({image, message = '', scale = 1}): () => Promise<void> {
  // Note: Runtime load of the "asciify-image" module, avoids including in browser bundles
  let asciify = null;
  try {
    asciify = module.require('asciify-image');
  } catch (error) {
    // asciify not installed, silently ignore
  }
  if (asciify) {
    return async () => {
      const data = await asciify(image, {fit: 'box', width: `${Math.round(80 * scale)}%`});
      console.log(data); // eslint-disable-line no-console
    };
  }

  return async () => {};
}
