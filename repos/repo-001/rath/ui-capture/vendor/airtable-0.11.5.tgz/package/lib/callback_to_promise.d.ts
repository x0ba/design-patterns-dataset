/**
 * Given a function fn that takes a callback as its last argument, returns
 * a new version of the function that takes the callback optionally. If
 * the function is not called with a callback for the last argument, the
 * function will return a promise instead.
 */
declare function callbackToPromise(fn: any, context: any, callbackArgIndex?: number): any;
export = callbackToPromise;
