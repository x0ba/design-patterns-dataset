// @flow
import React from 'react';
import type { PublicOwnProps } from './droppable-types';
import ConnectedDroppable from './connected-droppable';

// Public wrapper that fills in default values for optional props.
// React 19 removed defaultProps support for function components, so
// defaults are applied here instead of via ConnectedDroppable.defaultProps
// (mirrors the PublicDraggable pattern in ../draggable/draggable-api.jsx)
export default function PublicDroppable(props: PublicOwnProps) {
  return (
    <ConnectedDroppable
      {...props}
      mode={props.mode || 'standard'}
      type={props.type || 'DEFAULT'}
      direction={props.direction || 'vertical'}
      isDropDisabled={Boolean(props.isDropDisabled)}
      isCombineEnabled={Boolean(props.isCombineEnabled)}
      ignoreContainerClipping={Boolean(props.ignoreContainerClipping)}
      renderClone={props.renderClone || null}
      getContainerForClone={props.getContainerForClone || null}
    />
  );
}
