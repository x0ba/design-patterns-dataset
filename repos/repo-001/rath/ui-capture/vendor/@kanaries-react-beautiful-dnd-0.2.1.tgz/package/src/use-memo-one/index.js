// @flow
// Vendored from use-memo-one v1.1.3 (MIT License).
import { useRef, useState, useEffect } from 'react';
import areInputsEqual from './are-inputs-equal';

type Cache<T> = {|
  inputs: ?(mixed[]),
  result: T,
|};

export function useMemoOne<T>(getResult: () => T, inputs?: mixed[]): T {
  const initial: Cache<T> = useState(() => ({
    inputs,
    result: getResult(),
  }))[0];
  const isFirstRun = useRef<boolean>(true);
  const committed = useRef<Cache<T>>(initial);

  // Only reuse values from committed renders. This keeps the hook safe when
  // React starts and abandons concurrent renders.
  const useCache: boolean =
    isFirstRun.current ||
    Boolean(
      inputs &&
        committed.current.inputs &&
        areInputsEqual(inputs, committed.current.inputs),
    );

  const cache: Cache<T> = useCache
    ? committed.current
    : {
        inputs,
        result: getResult(),
      };

  useEffect(() => {
    isFirstRun.current = false;
    committed.current = cache;
  }, [cache]);

  return cache.result;
}

export function useCallbackOne<T: Function>(callback: T, inputs?: mixed[]): T {
  return useMemoOne(() => callback, inputs);
}

// Keep the aliases used throughout react-beautiful-dnd so dependency-array
// linting continues to treat these as useMemo and useCallback calls.
export const useMemo = useMemoOne;
export const useCallback = useCallbackOne;
