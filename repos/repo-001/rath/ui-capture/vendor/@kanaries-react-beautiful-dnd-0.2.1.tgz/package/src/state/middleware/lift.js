// @flow
// $FlowFixMe: flushSync is missing from flow's built-in react-dom libdef (flow 0.110)
import { flushSync } from 'react-dom';
import { invariant } from '../../invariant';
import type { DimensionMarshal } from '../dimension-marshal/dimension-marshal-types';
import type { State, ScrollOptions, LiftRequest } from '../../types';
import type { MiddlewareStore, Action, Dispatch } from '../store-types';
import {
  completeDrop,
  initialPublish,
  flush,
  beforeInitialCapture,
} from '../action-creators';
import validateDimensions from './util/validate-dimensions';

export default (marshal: DimensionMarshal) => ({
  getState,
  dispatch,
}: MiddlewareStore) => (next: Dispatch) => (action: Action): any => {
  if (action.type !== 'LIFT') {
    next(action);
    return;
  }
  const { id, clientSelection, movementMode } = action.payload;
  const initial: State = getState();

  // React 18/19 batch the state updates caused by these dispatches, so
  // without flushSync the resulting renders (removing placeholders,
  // consumer updates made in onBeforeCapture) would not be committed to
  // the DOM before startPublishing measures it below.
  // React <= 17 flushed the render of each dispatch synchronously.
  flushSync(() => {
    // flush dropping animation if needed
    // this can change the descriptor of the dragging item
    // Will call the onDragEnd responders

    if (initial.phase === 'DROP_ANIMATING') {
      dispatch(completeDrop({ completed: initial.completed }));
    }

    invariant(getState().phase === 'IDLE', 'Unexpected phase to start a drag');

    // Removing any placeholders before we capture any starting dimensions
    dispatch(flush());

    // Let consumers know we are just about to publish
    // We are only publishing a small amount of information as
    // things might change as a result of the onBeforeCapture callback
    dispatch(beforeInitialCapture({ draggableId: id, movementMode }));
  });

  // will communicate with the marshal to start requesting dimensions
  const scrollOptions: ScrollOptions = {
    shouldPublishImmediately: movementMode === 'SNAP',
  };
  const request: LiftRequest = {
    draggableId: id,
    scrollOptions,
  };
  // Let's get the marshal started!
  const { critical, dimensions, viewport } = marshal.startPublishing(request);

  validateDimensions(critical, dimensions);

  // Okay, we are good to start dragging now
  // Also committed synchronously: sensors and consumers expect the
  // DOM to reflect the dragging state as soon as the lift returns
  // (React <= 17 semantics)
  flushSync(() => {
    dispatch(
      initialPublish({
        critical,
        dimensions,
        clientSelection,
        movementMode,
        viewport,
      }),
    );
  });
};
