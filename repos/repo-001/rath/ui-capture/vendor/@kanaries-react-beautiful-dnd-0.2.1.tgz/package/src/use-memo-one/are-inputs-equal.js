// @flow
// Vendored from use-memo-one v1.1.3 (MIT License).

export default function areInputsEqual(
  newInputs: mixed[],
  lastInputs: mixed[],
): boolean {
  if (newInputs.length !== lastInputs.length) {
    return false;
  }

  for (let i = 0; i < newInputs.length; i++) {
    if (newInputs[i] !== lastInputs[i]) {
      return false;
    }
  }
  return true;
}
