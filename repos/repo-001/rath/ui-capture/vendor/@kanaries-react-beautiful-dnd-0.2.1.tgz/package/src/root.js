import { createContext, useContext } from 'react';

// Lazy getters: `document` must not be touched at module scope (or even
// at render time) so that importing and server-side rendering the
// package works in environments without a DOM. The properties are only
// read inside effects and event handlers, which are client-only.
const defaults = {
  get head() {
    return document.head;
  },
  get body() {
    return document.body;
  },
};

/** @type {import('react').Context<{ head: HTMLElement | ShadowRoot; body: HTMLElement | ShadowRoot }>} */
const Context = createContext(defaults);

export const useDOMContext = () => {
  return useContext(Context);
};

export const DOMProvider = Context.Provider;
