import 'mocha';
import 'chai';
import { lexer } from './array-lexer';
import { expect, assert } from 'chai';
import { parseArrayLiteral } from '../parser';
import { Optional } from '../utils';
import { Token } from 'moo';

describe('Array literals', () => {

    const hasContent = [
        /^value$/,
    ]
    function next(expected: any) {
        const result = lexer.next() as Optional<Token>;
        delete result.toString;
        delete result.col;
        delete result.line;
        delete result.lineBreaks;
        delete result.offset;
        delete result.text;
        if (!hasContent.some(x => x.test(result.type!))) {
            delete result.value;
        }
        expect(result).to.deep.equal(expected);
    }

    it('Lexer: tokenizes simple list', () => {
        lexer.reset(`{  a b , " a b " , "a\\" b"}`);
        next({ type: 'start_list' });
        next({ type: 'value', value: 'a b' });
        next({ type: 'comma' });
        next({ type: 'value', value: ' a b ' });
        next({ type: 'comma' });
        next({ type: 'value', value: 'a" b' });
        next({ type: 'end_list' });
    });

    it ('parses single array', () => {
        expect(parseArrayLiteral('{a}')).to.deep.equal(['a'])
    })

    it ('parses double array', () => {
        expect(parseArrayLiteral('{a, b}')).to.deep.equal(['a', 'b'])
    })


    it ('parses empty array', () => {
        expect(parseArrayLiteral('{}')).to.deep.equal([]);
    })

    it ('parses two dimensions', () => {
        expect(parseArrayLiteral('{{a}, {b, c}}')).to.deep.equal([['a'], ['b', 'c']])
    })
});