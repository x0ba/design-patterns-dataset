# Installation
> `npm install --save @types/koa__cors`

# Summary
This package contains type definitions for @koa/cors (https://github.com/koajs/cors).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/koa__cors.

### Additional Details
 * Last updated: Mon, 18 Apr 2022 23:03:04 GMT
 * Dependencies: [@types/koa](https://npmjs.com/package/@types/koa)
 * Global values: none

# Credits
These definitions were written by [Xavier Stouder](https://github.com/Xstoudi), [Steve Hipwell](https://github.com/stevehipwell), and [Steven McDowall](https://github.com/sjmcdowall).
