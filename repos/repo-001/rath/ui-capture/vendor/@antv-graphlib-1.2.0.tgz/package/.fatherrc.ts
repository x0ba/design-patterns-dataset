export default {
  esm: 'babel',
};
