# Installation
> `npm install --save @types/koa__router`

# Summary
This package contains type definitions for @koa/router (https://github.com/koajs/koa-router#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/koa__router.

### Additional Details
 * Last updated: Wed, 01 Dec 2021 02:31:09 GMT
 * Dependencies: [@types/koa](https://npmjs.com/package/@types/koa)
 * Global values: none

# Credits
These definitions were written by [Jerry Chin](https://github.com/hellopao), [Pavel Ivanov](https://github.com/schfkt), [JounQin](https://github.com/JounQin), [Romain Faust](https://github.com/romain-faust), [Guillaume Mayer](https://github.com/Guillaume-Mayer), [Andrea Gueugnaut](https://github.com/falinor), and [Jeremy Forsythe](https://github.com/jdforsythe).
