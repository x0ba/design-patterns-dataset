# @antv/g6-plugin

## 0.8.25

### Patch Changes

- Updated dependencies
  - @antv/g6@4.8.25
  - @antv/g6-element@0.8.25

## 0.8.24

### Patch Changes

- Migrate to pnpm manage
- Updated dependencies
  - @antv/g6-element@0.8.24
  - @antv/g6-core@0.8.24
